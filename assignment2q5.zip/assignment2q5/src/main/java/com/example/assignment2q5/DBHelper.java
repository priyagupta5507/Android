package com.example.assignment2q5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(@Nullable Context context) {
        super(context, "EmployeeDB", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table Employee(id integer primary key, empname text, deptname text, salary text)";
        db.execSQL(sql);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String sql = "drop table if exists Employee";
        db.execSQL(sql);
        onCreate(db);
    }
}