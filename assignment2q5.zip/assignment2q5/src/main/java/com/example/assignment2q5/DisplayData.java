package com.example.assignment2q5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayData extends AppCompatActivity {
    DBHelper dBmain;
    SQLiteDatabase sqLiteDatabase;
    ListView listView;
    Button search;
    EditText nm;
    String []name;
    String []deptname;
    String []salary;
    int []id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_data);
        search = findViewById(R.id.search);
        nm = findViewById(R.id.searchData);
        dBmain = new DBHelper(DisplayData.this);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n = nm.getText().toString();
                sqLiteDatabase = getApplicationContext().openOrCreateDatabase("EmployeeDB", Context.MODE_PRIVATE,null);
                Cursor cursor = sqLiteDatabase.rawQuery("select * from Employee where empname='"+n+"'",null);
                if(cursor.getCount()==0)
                {
                    Toast.makeText(DisplayData.this,"No Record Found",Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer stringBuffer = new StringBuffer();
                while(cursor.moveToNext())
                {
                    stringBuffer.append("Employee Id : \t"+cursor.getString(0)+"\n");
                    stringBuffer.append("Employee Name : \t"+cursor.getString(1)+"\n");
                    stringBuffer.append("Dept Name : \t"+cursor.getString(2)+"\n");
                    stringBuffer.append("Salary : \t"+cursor.getString(3)+"\n");
                }
                Toast.makeText(DisplayData.this,"Result \n"+stringBuffer.toString(),Toast.LENGTH_SHORT).show();
            }
        });
//create method
        findid();
        dis();
    }
    private void dis() {
        sqLiteDatabase = dBmain.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from Employee",null);
        if(cursor.getCount()>0){
            id = new int[cursor.getCount()];
            name = new String[cursor.getCount()];
            deptname = new String[cursor.getCount()];
            salary = new String[cursor.getCount()];
            int i = 0;
            while(cursor.moveToNext()){
                id[i] = cursor.getInt(0);
                name[i] = cursor.getString(1);
                deptname[i] = cursor.getString(2);
                salary[i] = cursor.getString(3);
                i++;
            }
            Custom adapter = new Custom();
            listView.setAdapter(adapter);
        }else{
            startActivity(new Intent(DisplayData.this, MainActivity.class));
        }
    }
    private void findid() {
        listView = findViewById(R.id.listView);
    }
    private class Custom extends BaseAdapter {
        @Override
        public int getCount() {
            return name.length;
        }
        @Override
        public Object getItem(int i) {
            return null;
        }
        @Override
        public long getItemId(int i) {
            return 0;
        }
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            TextView textView,textView1,textView2;
            ImageView edit,delete;
            Button search;
            view = LayoutInflater.from(DisplayData.this).inflate(R.layout.activity_singledata, viewGroup,false);
            textView = view.findViewById(R.id.txt_name);
            textView1 = view.findViewById(R.id.txtDept);
            textView2 = view.findViewById(R.id.txtSalary);
            edit = view.findViewById(R.id.edit_data);
            delete = view.findViewById(R.id.delete_data);

            textView.setText(name[i]);
            textView1.setText(deptname[i]);
            textView2.setText(salary[i]);
            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("id",id[i]);
                    bundle.putString("empname",name[i]);
                    bundle.putString("deptname",deptname[i]);
                    bundle.putString("salary",salary[i]);
                    Intent intent = new Intent(DisplayData.this, MainActivity.class);
                    intent.putExtra("userdata",bundle);
                    startActivity(intent);
                }
            });
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sqLiteDatabase = dBmain.getReadableDatabase();
                    long resid =
                            sqLiteDatabase.delete("Employee","id="+id[i],null);
                    if(resid != -1){
                        Toast.makeText(DisplayData.this,"Record Deleted",Toast.LENGTH_SHORT).show();
                        dis();
                    }else{
                        Toast.makeText(DisplayData.this,"Record not Deleted",Toast.LENGTH_SHORT).show();
                    }
                }
            });


            return view;
        }

    }
}