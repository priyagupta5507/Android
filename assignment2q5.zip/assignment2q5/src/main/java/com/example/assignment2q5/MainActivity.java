package com.example.assignment2q5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.nio.file.Paths;

public class MainActivity extends AppCompatActivity {

    private static DBHelper dbmain;
    private static EditText txtName, txtDept, txtSalary;
    private static Button submitbtn, editbtn, displaybtn;
    private static SQLiteDatabase sqLiteDatabase;
    private static int id = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbmain = new DBHelper(MainActivity.this);
//Create Method
        findid();
        getData();
        clear();
        editData();
    }
    private void editData() {
        if(getIntent().getBundleExtra("userdata") != null){
            Bundle bundle = getIntent().getBundleExtra("userdata");
            id=bundle.getInt("id");
            txtName.setText(bundle.getString("empname"));
            txtDept.setText(bundle.getString("deptname"));
            txtSalary.setText(bundle.getString("salary"));
            editbtn.setVisibility(View.VISIBLE);
            submitbtn.setVisibility(View.GONE);
        }
    }
    private void clear() {
        txtName.setText("");
        txtDept.setText("");
        txtSalary.setText("");
    }
    private void getData() {
//insert
        submitbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("empname",txtName.getText().toString());
                contentValues.put("deptname",txtDept.getText().toString());
                contentValues.put("salary",txtSalary.getText().toString());
                sqLiteDatabase = dbmain.getWritableDatabase();
                Long resid = sqLiteDatabase.insert("Employee", null,contentValues);
                if(resid != null){
                    Toast.makeText(MainActivity.this, "Inserted Successfully", Toast.LENGTH_SHORT).show();
                    clear();
                }else{
                    Toast.makeText(MainActivity.this, "Error while inserting the record", Toast.LENGTH_SHORT).show();
                }
            }
        });
//display data
        displaybtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,DisplayData.class));
            }
        });
//edit data
        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("empname",txtName.getText().toString());
                contentValues.put("deptname",txtDept.getText().toString());
                contentValues.put("salary",txtSalary.getText().toString());
                sqLiteDatabase = dbmain.getWritableDatabase();
                long resid = sqLiteDatabase.update("Employee", contentValues, "id="+id,null);
                if(resid != -1){
                    Toast.makeText(MainActivity.this, "Updated Successfully", Toast.LENGTH_SHORT).show();
                    submitbtn.setVisibility(View.VISIBLE);
                    editbtn.setVisibility(View.GONE);
                    clear();
                }else{
                    Toast.makeText(MainActivity.this, "Error while updating record", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    private void findid() {
        txtName = (EditText) findViewById(R.id.txtName);
        txtDept = (EditText) findViewById(R.id.txtDept);
        txtSalary = (EditText) findViewById(R.id.txtSalary);
        submitbtn = findViewById(R.id.btn_submit);
        editbtn = findViewById(R.id.btn_edit);
        displaybtn = findViewById(R.id.btn_display);


    }
}